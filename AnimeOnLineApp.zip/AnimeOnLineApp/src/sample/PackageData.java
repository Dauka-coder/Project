package sample;

import java.io.Serializable;

public class PackageData implements Serializable {
    private String typeofOperation;
    private String message;
    private Anime anime;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public PackageData(String message, String typeofOperation) {
        this.message = message;
        this.typeofOperation = typeofOperation;
    }

    public PackageData(Anime anime, String typeofOperation) {
        this.anime = anime;
        this.typeofOperation = typeofOperation;
    }


    public PackageData(String typeofOperation) {
        this.typeofOperation = typeofOperation;
    }

    public void setTypeofOperation(String typeofOperation) { this.typeofOperation = typeofOperation; }

    public String getTypeofOperation() { return typeofOperation; }

    public Anime getAnime() {
        return anime;
    }

    public void setAnime(Anime anime) {
        this.anime = anime;
    }
}
