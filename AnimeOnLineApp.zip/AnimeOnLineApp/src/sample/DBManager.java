package sample;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static sample.Join.nicknameText;

public class DBManager extends Controller {
    private Connection connection;

    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/animeonline?useUnicode=true&serverTimezone=UTC", "root", "");
            System.out.println("connect");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

        public void addAnime(Anime anime){
            try{
                PreparedStatement statement = connection.prepareStatement("" +
                        "INSERT INTO anime (Code, NameAnime, Descript, Photo, Video, ShowTime, ShowTime2, anime_1, anime_2, anime_3, anime_4) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                statement.setString(1, anime.getAnime_Code());
                statement.setString(2, anime.getAnime_Name());
                statement.setString(3, anime.getAnime_Descript());
                statement.setString(4, anime.getAnime_Photo());
                statement.setString(5, anime.getAnime_Video());
                statement.setString(6, anime.getAnime_ShowTime());
                statement.setString(7, anime.getAnime_ShowTime2());
                statement.setString(8, anime.getAnime_1());
                statement.setString(9, anime.getAnime_2());
                statement.setString(10,anime.getAnime_3());
                statement.setString(11,anime.getAnime_4());

                int rows = statement.executeUpdate();

                statement.close();

            }catch (Exception e){
                e.printStackTrace();
            }
    }

    public void addUser(String User) {
        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO users (ID,User) " +
                    "VALUES (NULL, ?)"
            );
            statement.setString(1, User);

            int rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addRecommendation(String Recommendation) {
        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO recommendations (Recommendations) " +
                    "VALUES (?)"
            );
            statement.setString(1, Recommendation);

            int rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String GIVEINFO(String string){
        try{

            PreparedStatement statement = connection.prepareStatement("SELECT * FROM anime");
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()){
                String STRING = resultSet.getString(string);
                return STRING;
            }
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        if (string == "NameAnime")
            return "Сегодня нет показов";
        else
        return "";
    }

    public void DeleteAllAnime(){
        try{
            PreparedStatement statement = connection.prepareStatement("" +
                    "DELETE FROM anime"
            );
            statement.executeUpdate();
            statement.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void DeleteUser(){
        try{
            PreparedStatement statement = connection.prepareStatement("" +
                    "DELETE FROM users WHERE User =?"
            );
            statement.setString(1, nicknameText);
            statement.executeUpdate();
            statement.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public int GIVECOUNT(String string){
        try{
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM poll");
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()){
                Integer count = resultSet.getInt(string);
                return count;
            }
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    public void ChangeCount(String string,int newCount){
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE poll SET "+ string+"="+newCount);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void Zeroing(){
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE poll SET Yes_1=0,No_1=0,Yes_2=0,No_2=0,Yes_3=0,No_3=0,anime_1=0,anime_2=0,anime_3=0,anime_4=0");
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public ObservableList<String> Info(){
        ObservableList<String> info = FXCollections.observableArrayList();
        try{

            PreparedStatement statement = connection.prepareStatement("SELECT * FROM recommendations");
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()){
                String recom =resultSet.getString("Recommendations");
                info.add(recom+"\n"+"--------------------------------------------------------------------------------------------");
            }
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return info;
    }
}