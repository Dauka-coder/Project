package sample;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ServerThread extends Thread{
    private Socket socket;

    public ServerThread(java.net.Socket socket) {
        this.socket = socket;
    }

    public void run(){
        try{
            DBManager manager = new DBManager();
            manager.connect();

            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

            PackageData packageData = null;
            while ( (packageData=(PackageData)inputStream.readObject())!=null ) {
                if (packageData.getTypeofOperation().equals("ADD ANIME")) {
                    Anime anime = packageData.getAnime();
                    manager.addAnime(anime);
                }
                else if (packageData.getTypeofOperation().equals("ADD USER")) {
                    String AllMessages = packageData.getMessage();
                    manager.addUser(AllMessages);
                }
                else if (packageData.getTypeofOperation().equals("ADD RECOMMENDATION")) {
                    String Recommendation = packageData.getMessage();
                    manager.addRecommendation(Recommendation);
                }
            }

            inputStream.close();
            outputStream.close();
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
