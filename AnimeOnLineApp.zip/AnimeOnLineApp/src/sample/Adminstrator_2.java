package sample;

import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import static sample.Events.EVENTS;

public class Adminstrator_2 {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Close;

    @FXML
    private Button RollUp;

    @FXML
    private TextArea data1;

    @FXML
    private TextArea data2;

    @FXML
    private TextArea data3;

    @FXML
    private TextArea anime1;

    @FXML
    private TextArea data4;

    @FXML
    private TextArea anime2;

    @FXML
    private TextArea data5;

    @FXML
    private TextArea anime3;

    @FXML
    private TextArea data6;

    @FXML
    private TextArea anime4;

    @FXML
    private TextArea data7;

    @FXML
    private Button Back;

    @FXML
    private TextArea recommendations;

    @FXML
    private Text eventsofthedays;
    @FXML
    void initialize() {
        DBManager manager = new DBManager();
        manager.connect();

        Close.setOnAction(event -> {
            Stage stage = (Stage) Close.getScene().getWindow();
            stage.close();
        });

        RollUp.setOnAction(event -> {
            Stage stage = null;

            stage = (Stage) RollUp.getScene().getWindow();
            stage.setIconified(true);
        });

        Back.setOnAction(event -> {
            Stage stage1 = (Stage) Back.getScene().getWindow();
            stage1.close();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/Adminstrator.fxml"));
            try{
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.setTitle("Anime Online");
            stage.getIcons().add(new Image("/sample/Assets/iCON.jpg"));
            stage.setResizable(false);
            stage.setFullScreen(true);
            stage.setFullScreenExitHint("");
            stage.show();
        });

        data1.setText(manager.GIVECOUNT("Yes_1")+" из " + (manager.GIVECOUNT("Yes_1")+manager.GIVECOUNT("No_1")));
        data2.setText(manager.GIVECOUNT("Yes_2")+" из " + (manager.GIVECOUNT("Yes_2")+manager.GIVECOUNT("No_2")));
        data3.setText(manager.GIVECOUNT("Yes_3")+" из " + (manager.GIVECOUNT("Yes_3")+manager.GIVECOUNT("No_3")));
        data4.setText(manager.GIVECOUNT("anime_1")+ " из "+(manager.GIVECOUNT("anime_1")+manager.GIVECOUNT("anime_2")+manager.GIVECOUNT("anime_3")+manager.GIVECOUNT("anime_4")));
        data5.setText(manager.GIVECOUNT("anime_2")+ " из "+(manager.GIVECOUNT("anime_1")+manager.GIVECOUNT("anime_2")+manager.GIVECOUNT("anime_3")+manager.GIVECOUNT("anime_4")));
        data6.setText(manager.GIVECOUNT("anime_3")+ " из "+(manager.GIVECOUNT("anime_1")+manager.GIVECOUNT("anime_2")+manager.GIVECOUNT("anime_3")+manager.GIVECOUNT("anime_4")));
        data7.setText(manager.GIVECOUNT("anime_4")+ " из "+(manager.GIVECOUNT("anime_1")+manager.GIVECOUNT("anime_2")+manager.GIVECOUNT("anime_3")+manager.GIVECOUNT("anime_4")));

        anime1.setText(manager.GIVEINFO("anime_1"));
        anime2.setText(manager.GIVEINFO("anime_2"));
        anime3.setText(manager.GIVEINFO("anime_3"));
        anime4.setText(manager.GIVEINFO("anime_4"));

        recommendations.setWrapText(true);

        DBManager man =new DBManager();
        man.connect();

        ObservableList<String> listStudents = FXCollections.observableArrayList();
        recommendations.setText(String.valueOf(listStudents = man.Info()));
        recommendations.setEditable(false);

        Calendar time = new GregorianCalendar();
        eventsofthedays.setText(EVENTS(time));
    }
}
