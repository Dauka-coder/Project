package sample;

import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.scene.control.Slider;
import javafx.util.Duration;
import javafx.scene.control.TextArea;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import org.omg.CORBA.TRANSACTION_MODE;

import static sample.Events.EVENTS;
import static sample.Join.nicknameText;

public class User{

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button button_play;

    @FXML
    private Button Back;

    @FXML
    private RadioButton Yes_1;

    @FXML
    private RadioButton No_1;

    @FXML
    private RadioButton Yes_2;

    @FXML
    private RadioButton No_2;

    @FXML
    private TextArea textArea;

    @FXML
    private RadioButton Yes_3;

    @FXML
    private RadioButton No_3;

    @FXML
    private RadioButton anime_1;

    @FXML
    private RadioButton anime_2;

    @FXML
    private RadioButton anime_3;

    @FXML
    private RadioButton anime_4;

    @FXML
    private Text eventsofday;

    @FXML
    private Button Close;

    @FXML
    private Button RollUp;

    MediaPlayer player;

    @FXML
    private MediaView mediaView;

    @FXML
    private Slider timeSlider;

    @FXML
    void initialize() {
        DBManager manager = new DBManager();
        manager.connect();

        ToggleGroup group1 = new ToggleGroup();
        Yes_1.setToggleGroup(group1);
        No_1.setToggleGroup(group1);

        ToggleGroup group2 = new ToggleGroup();
        Yes_2.setToggleGroup(group2);
        No_2.setToggleGroup(group2);

        ToggleGroup group3 = new ToggleGroup();
        Yes_3.setToggleGroup(group3);
        No_3.setToggleGroup(group3);

        ToggleGroup group4 = new ToggleGroup();
        anime_1.setToggleGroup(group4);
        anime_2.setToggleGroup(group4);
        anime_3.setToggleGroup(group4);
        anime_4.setToggleGroup(group4);

        Yes_1.setSelected(true);
        Yes_2.setSelected(true);
        Yes_3.setSelected(true);
        anime_1.setSelected(true);

        anime_1.setText(manager.GIVEINFO("anime_1"));
        anime_2.setText(manager.GIVEINFO("anime_2"));
        anime_3.setText(manager.GIVEINFO("anime_3"));
        anime_4.setText(manager.GIVEINFO("anime_4"));

        textArea.setWrapText(true);

        try {
            Media media = new Media(manager.GIVEINFO("Video"));

            player = new MediaPlayer(media);

            mediaView.setMediaPlayer(player);

            Image imageOk = new Image(getClass().getResourceAsStream("Assets\\3.png"));
            button_play.graphicProperty().setValue(new ImageView(imageOk));

            player.setOnReady(() -> {
                timeSlider.setMin(0);
                timeSlider.setMax(player.getMedia().getDuration().toSeconds());
                timeSlider.setValue(0);
            });

            player.currentTimeProperty().addListener(new ChangeListener<Duration>() {
                @Override
                public void changed(ObservableValue<? extends Duration> observable, Duration oldValue, Duration newValue) {
                    Duration time = player.getCurrentTime();

                    timeSlider.setValue(time.toSeconds());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        Close.setOnAction(event -> {
            manager.DeleteUser();

            if(!textArea.getText().trim().equals("")) {
                String recom = ("От пользователя " + nicknameText + ": " + textArea.getText());
                PackageData pd = new PackageData(recom, "ADD RECOMMENDATION");
                Main.connect(pd); }

            int a;

            if(Yes_1.isSelected()){
                a = manager.GIVECOUNT("Yes_1");
                a++;
                manager.ChangeCount("Yes_1",a);
            }

            if(No_1.isSelected()){
                a = manager.GIVECOUNT("No_1");
                a++;
                manager.ChangeCount("No_1",a);
            }

            if(Yes_2.isSelected()){
                a = manager.GIVECOUNT("Yes_2");
                a++;
                manager.ChangeCount("Yes_2",a);
            }

            if(No_2.isSelected()){
                a = manager.GIVECOUNT("No_2");
                a++;
                manager.ChangeCount("No_2",a);
            }

            if(Yes_3.isSelected()){
                a = manager.GIVECOUNT("Yes_3");
                a++;
                manager.ChangeCount("Yes_3",a);
            }

            if(No_3.isSelected()){
                a = manager.GIVECOUNT("No_3");
                a++;
                manager.ChangeCount("No_3",a);
            }

            if(anime_1.isSelected()){
                a = manager.GIVECOUNT("anime_1");
                a++;
                manager.ChangeCount("anime_1",a);
            }

            if(anime_2.isSelected()){
                a = manager.GIVECOUNT("anime_2");
                a++;
                manager.ChangeCount("anime_2",a);
            }

            if(anime_3.isSelected()){
                a = manager.GIVECOUNT("anime_2");
                a++;
                manager.ChangeCount("anime_2",a);
            }

            if(anime_4.isSelected()){
                a = manager.GIVECOUNT("anime_2");
                a++;
                manager.ChangeCount("anime_2",a);
            }

            Stage stage = (Stage) Close.getScene().getWindow();
            stage.close();
        });

        RollUp.setOnAction(event -> {
            Stage stage = null;

            stage = (Stage) RollUp.getScene().getWindow();
            stage.setIconified(true);
        });

        Back.setOnAction(event -> {
            player.pause();

            Stage stage1 = (Stage) Back.getScene().getWindow();
            stage1.close();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/sample.fxml"));
            try{
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.setTitle("Anime Online");
            stage.getIcons().add(new Image("/sample/Assets/iCON.jpg"));
            stage.setResizable(false);
            stage.setFullScreen(true);
            stage.setFullScreenExitHint("");
            stage.show();

            if(!textArea.getText().trim().equals("")) {
                String recom = ("От пользователя " + nicknameText + ": " + textArea.getText());
                PackageData pd = new PackageData(recom, "ADD RECOMMENDATION");
                Main.connect(pd); }

            manager.DeleteUser();

            int a;

            if(Yes_1.isSelected()){
                a = manager.GIVECOUNT("Yes_1");
                a++;
                manager.ChangeCount("Yes_1",a);
            }

            if(No_1.isSelected()){
                a = manager.GIVECOUNT("No_1");
                a++;
                manager.ChangeCount("No_1",a);
            }

            if(Yes_2.isSelected()){
                a = manager.GIVECOUNT("Yes_2");
                a++;
                manager.ChangeCount("Yes_2",a);
            }

            if(No_2.isSelected()){
                a = manager.GIVECOUNT("No_2");
                a++;
                manager.ChangeCount("No_2",a);
            }

            if(Yes_3.isSelected()){
                a = manager.GIVECOUNT("Yes_3");
                a++;
                manager.ChangeCount("Yes_3",a);
            }

            if(No_3.isSelected()){
                a = manager.GIVECOUNT("No_3");
                a++;
                manager.ChangeCount("No_3",a);
            }

            if(anime_1.isSelected()){
                a = manager.GIVECOUNT("anime_1");
                a++;
                manager.ChangeCount("anime_1",a);
            }

            if(anime_2.isSelected()){
                a = manager.GIVECOUNT("anime_2");
                a++;
                manager.ChangeCount("anime_2",a);
            }

            if(anime_3.isSelected()){
                a = manager.GIVECOUNT("anime_3");
                a++;
                manager.ChangeCount("anime_3",a);
            }

            if(anime_4.isSelected()){
                a = manager.GIVECOUNT("anime_4");
                a++;
                manager.ChangeCount("anime_4",a);
            }
        });

        button_play.setOnAction(event -> {
            double val;
            String string = manager.GIVEINFO("ShowTime2");
            String delimeter = "\\:";
            String[] subStr;
            subStr = string.split(delimeter);
            Date now = new Date();
            val = ((now.getHours() - Integer.parseInt(subStr[0])) * 3600 + (now.getMinutes() - Integer.parseInt(subStr[1])) * 60 + now.getSeconds()) * 1000;
            new Thread(() -> player.seek(new Duration(val))).start();

            player.play();
            button_play.setVisible(false);
        });

        Calendar time = new GregorianCalendar();
        eventsofday.setText(EVENTS(time));
    }
}

