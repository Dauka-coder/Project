package sample;

import java.io.Serializable;
import java.sql.Date;

public class Anime implements Serializable {
    private String anime_Code;
    private String anime_Name;
    private String anime_Descript;
    private String anime_Photo;
    private String anime_Video;
    private String anime_ShowTime;
    private String anime_ShowTime2;
    private String anime_1;
    private String anime_2;
    private String anime_3;
    private String anime_4;

    public String getAnime_Code() {
        return anime_Code;
    }

    public void setAnime_Code(String anime_Code) {
        this.anime_Code = anime_Code;
    }

    public String getAnime_Descript() {
        return anime_Descript;
    }

    public void setAnime_Descript(String anime_Descript) {
        this.anime_Descript = anime_Descript;
    }

    public String getAnime_Name() {
        return anime_Name;
    }

    /*public Date getAnime_time() {
        return anime_time;
    }

    public void setAnime_time(Date anime_time) {
        this.anime_time = anime_time;
    }
     */

    public String getAnime_Photo() {
        return anime_Photo;
    }

    public String getAnime_Video() {
        return anime_Video;
    }

    public String getAnime_ShowTime() {
        return anime_ShowTime;
    }

    public void setAnime_ShowTime(String anime_ShowTime) {
        this.anime_ShowTime = anime_ShowTime;
    }

    public void setAnime_Video(String anime_Video) {
        this.anime_Video = anime_Video;
    }

    public void setAnime_Photo(String anime_Photo) {
        this.anime_Photo = anime_Photo;
    }

    public void setAnime_Name(String anime_Name) {
        this.anime_Name = anime_Name;
    }

    public String getAnime_ShowTime2() {
        return anime_ShowTime2;
    }

    public void setAnime_ShowTime2(String anime_ShowTime2) {
        this.anime_ShowTime2 = anime_ShowTime2;
    }

    public String getAnime_1() { return anime_1; }

    public void setAnime_1(String anime_1) { this.anime_1 = anime_1; }

    public String getAnime_2() { return anime_2; }

    public void setAnime_2(String anime_2) { this.anime_2 = anime_2; }

    public String getAnime_3() { return anime_3; }

    public void setAnime_3(String anime_3) { this.anime_3 = anime_3; }

    public String getAnime_4() { return anime_4; }

    public void setAnime_4(String anime_4) { this.anime_4 = anime_4; }

    public Anime(String anime_Code, String anime_Name, String anime_Descript, String anime_Photo, String anime_Video, String anime_ShowTime, String anime_ShowTime2, String anime_1, String anime_2, String anime_3, String anime_4) {
        this.anime_Code = anime_Code;
        this.anime_Name = anime_Name;
        this.anime_Descript = anime_Descript;
        this.anime_Photo = anime_Photo;
        this.anime_Video = anime_Video;
        this.anime_ShowTime = anime_ShowTime;
        this.anime_ShowTime2 = anime_ShowTime2;
        this.anime_1 = anime_1;
        this.anime_2 = anime_2;
        this.anime_3 = anime_3;
        this.anime_4 = anime_4;
    }
}
