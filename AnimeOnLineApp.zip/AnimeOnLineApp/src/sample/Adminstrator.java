package sample;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;

import static sample.Events.EVENTS;
import static sample.Join.count;
import static sample.Controller.counter;

public class Adminstrator{
    @FXML
    private Button Close;

    @FXML
    private Button RollUp;

    @FXML
    private TextField need_day;

    @FXML
    private TextField need_month;

    @FXML
    private TextField need_years;

    @FXML
    private TextField need_hours;

    @FXML
    private TextField need_minutes;

    @FXML
    private TextField need_code;

    @FXML
    private Button Add;

    @FXML
    private Button add_photo;

    @FXML
    private TextField anime_name;

    @FXML
    private TextArea anime_Descript;

    @FXML
    private Text eventsofthedays;

    @FXML
    private Button add_video;

    @FXML
    private Button deleteAll;

    @FXML
    private TextField anime_name_1;

    @FXML
    private TextField anime_name_2;

    @FXML
    private TextField anime_name_3;

    @FXML
    private TextField anime_name_4;

    @FXML
    private Button viewResult;


    @FXML
    private Button Back;
    protected static Date needtime1;
    protected static String needCode;
    protected static File file1;
    protected static File file;
    protected static Calendar needtime;

    protected static String nameOfAnime = "Сегодня нет показов";
    protected static String DescriptOfAnime;
    protected static String timeOfAnime;
    protected static String timeOfAnime2;
    private String anime_photo;
    private String anime_video;

    @FXML
    void initialize() {
        DBManager manager = new DBManager();
        manager.connect();

        Close.setOnAction(event -> {
            Stage stage = (Stage) Close.getScene().getWindow();
            stage.close();
        });

        RollUp.setOnAction(event -> {
            Stage stage = null;

            stage = (Stage) RollUp.getScene().getWindow();
            stage.setIconified(true);
        });

        Back.setOnAction(event -> {
            Stage stage1 = (Stage) Back.getScene().getWindow();
            stage1.close();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/sample.fxml"));
            try{
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.setTitle("Anime Online");
            stage.getIcons().add(new Image("/sample/Assets/iCON.jpg"));
            stage.setResizable(false);
            stage.setFullScreen(true);
            stage.setFullScreenExitHint("");
            stage.show();

        });

        add_video.setOnAction(event -> {
            FileChooser chooser = new FileChooser();
            file = chooser.showOpenDialog(null);
            try {
                anime_video = file.toURI().toURL().toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        });

        add_photo.setOnAction(event -> {
            FileChooser chooser = new FileChooser();
            file1 = chooser.showOpenDialog(null);
            try {
                anime_photo = file1.toURI().toURL().toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        });

        deleteAll.setOnAction(event -> {
            manager.DeleteAllAnime();
        });

        Add.setOnAction(event -> {
            String needday = need_day.getText().trim();
            String needmonth = need_month.getText().trim();
            String needyears = need_years.getText().trim();
            String needhours = need_hours.getText().trim();
            String needminutes = need_minutes.getText().trim();
            needCode = need_code.getText().trim();

            String anime_1 = anime_name_1.getText();
            String anime_2 = anime_name_2.getText();
            String anime_3 = anime_name_3.getText();
            String anime_4 = anime_name_4.getText();

            nameOfAnime = anime_name.getText();
            DescriptOfAnime = anime_Descript.getText();
            timeOfAnime = (needday+"."+needmonth+"."+needyears);
            timeOfAnime2 = (needhours+":"+needminutes);

            count = 0;
            counter++;

            Anime anime = new Anime(needCode,nameOfAnime,DescriptOfAnime,anime_photo,anime_video,timeOfAnime,timeOfAnime2,anime_1,anime_2,anime_3,anime_4);
            PackageData pd = new PackageData(anime,"ADD ANIME");
            Main.connect(pd);

            manager.Zeroing();
        });

        viewResult.setOnAction(event -> {
            Stage stage1 = (Stage) Back.getScene().getWindow();
            stage1.close();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/Adminstrator_2.fxml"));
            try{
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.setTitle("Anime Online");
            stage.getIcons().add(new Image("/sample/Assets/iCON.jpg"));
            stage.setResizable(false);
            stage.setFullScreen(true);
            stage.setFullScreenExitHint("");
            stage.show();
        });

        anime_Descript.setWrapText(true);
        Calendar time = new GregorianCalendar();
        eventsofthedays.setText(EVENTS(time));
    }
}
